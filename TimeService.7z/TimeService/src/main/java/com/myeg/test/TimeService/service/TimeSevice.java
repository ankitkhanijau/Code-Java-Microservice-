package com.myeg.test.TimeService.service;

/**
 * 
 * @author Ankit Khanijau
 * @date 28th Mar 2023
 * @version Time Service v1.0
 * @apiNote Code written as per wowcher code test.
 *
 */
public interface TimeSevice {
	
	String getTime(String currentTime);
	
	String getDay(String currentTime);

}
