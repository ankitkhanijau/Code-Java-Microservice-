package com.myeg.test.TimeService.service.impl;

import org.springframework.stereotype.Service;

import com.myeg.test.TimeService.service.TimeSevice;
import com.myeg.test.TimeService.utility.TimeUtility;
import com.myeg.test.TimeService.utility.ValidateUtility;

/**
 * 
 * @author Ankit Khanijau
 * @date 28th Mar 2023
 * @version Time Service v1.0
 * @apiNote Code written as per wowcher code test.
 *
 */
@Service
public class TimeServiceImpl implements TimeSevice {
	
	@Override
	public String getTime(String currentTime) {
		if (currentTime == null) {
			currentTime = ValidateUtility.getTime();
		} 
		
		if(ValidateUtility.validateText(currentTime)) {
			String firtHalf = TimeUtility.getTimeInWords(currentTime.substring(0,2));
			String secondHalf = TimeUtility.getTimeInWords(currentTime.substring(3), true);
			
			String time = null;  
			if(firtHalf.equals("") && secondHalf.equals("")) { 
				time = "It's zero o'clock. ";
			} else {
				time = "It's " + firtHalf + " " + secondHalf + ". ";
			}
			
			
			return time + getDay(currentTime);
		} else {
			return "Invalid time format entered.";
		}
	}

	@Override
	public String getDay(String currentTime) {
		int firstHalf = Integer.parseInt(currentTime.substring(0,2));
		
		if(firstHalf >=19 || firstHalf<=6 ) {
			return "It's Midnight.";
		} else if(firstHalf <=18 || firstHalf>=7 ) {
			return "It's Midday.";
		} 
		return null;
	}

	
	public static void main(String[] args) {
		System.out.println(new TimeServiceImpl().getTime("08:34"));
	}
}
