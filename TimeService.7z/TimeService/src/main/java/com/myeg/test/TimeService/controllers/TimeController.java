package com.myeg.test.TimeService.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.myeg.test.TimeService.service.TimeSevice;

/**
 * 
 * @author Ankit Khanijau
 * @date 28th Mar 2023
 * @version Time Service v1.0
 * @apiNote Code written as per wowcher code test.
 *
 */
@RestController
@RequestMapping("/time")
public class TimeController {
	
	@Autowired
	private TimeSevice timeservice;

	@GetMapping("/{time}")
	public ResponseEntity<String> getTime(@PathVariable String time) {
		String timr = timeservice.getTime(time);
		return ResponseEntity.ok(timr);
	}
}
