package com.myeg.test.TimeService.utility;

import com.myeg.test.TimeService.constant.TimeConstants;

/**
 * 
 * @author Ankit Khanijau
 * @date 28th Mar 2023
 * @version Time Service v1.0
 * @apiNote Code written as per wowcher code test.
 *
 */
public class TimeUtility implements TimeConstants {
	
	public static String getTimeInWords(String num) {
		return getTimeInWords(num, false);
	}
	
	public static String getTimeInWords(String num, boolean isMinute) {
		String op = null;
		if (num != null && num.length() <= 2) {
			int intNum = Integer.parseInt(num);
			
			boolean cond = false;
			if(isMinute) {
				cond = intNum >= 20 && intNum <= 59;
			} else {
				cond = intNum >= 20 && intNum <= 23;
			}
			
			if(cond) {
				String firstVal = num.substring(0, 1);
				String secondVal = num.substring(1);

				if(firstVal.equals("2") || (firstVal.equals("2") && secondVal.equals("0"))) {
					op = TY_20;
				} else if(firstVal.equals("3") || (firstVal.equals("3") && secondVal.equals("0"))) {
					op = TY_30;
				} else if(firstVal.equals("4") || (firstVal.equals("4") && secondVal.equals("0"))) {
					op = TY_40; 
				} else if(firstVal.equals("5") || (firstVal.equals("5") && secondVal.equals("0"))) {
					op = TY_50;
				} else if(firstVal.equals("6") && secondVal.equals("0")) {
					op = "";
				}

				if(!secondVal.equals("0")) {
					op = op + " " + getFrstNine(secondVal);
				}

			} else if(intNum < 20) {

				if(intNum <= 9 && intNum > 0) {
					op = getFrstNine(String.valueOf(intNum));
				} else if(num.equals("10")) {
					op = DD_10;
				} else if (num.equals("11")) {
					op = DD_11;
				} else if (num.equals("12")) {
					op = DD_12;
				} else if (num.equals("13")) {
					op = DD_13;
				} else if (num.equals("14")) {
					op = DD_14;
				} else if (num.equals("15")) {
					op = DD_15;
				} else if (num.equals("16")) {
					op = DD_16;
				} else if (num.equals("17")) {
					op = DD_17;
				} else if (num.equals("18")) {
					op = DD_18;
				} else if (num.equals("19")) {
					op = DD_19;
				} else if (num.equals("0") || num.equals("00")) {
					op = "";
				}
			} else {
				return "Invalid num.";
			}
		} else {
			return "Invalid num.";
		}
		return op;
	}
	
	private static String getFrstNine(String val) {
		if(val.equals("1")) {
			return SD_1;
		} else if(val.equals("2")) {
			return SD_2;
		} else if(val.equals("3")) {
			return SD_3;
		} else if(val.equals("4")) {
			return SD_4;
		} else if(val.equals("5")) {
			return SD_5;
		} else if(val.equals("6")) {
			return SD_6;
		} else if(val.equals("7")) {
			return SD_7;
		} else if(val.equals("8")) {
			return SD_8;
		} else if(val.equals("9")) {
			return SD_9;
		}
		
		return null;
	}
	
	
	  public static void main(String[] args) {
	  System.out.println(TimeUtility.getTimeInWords("24")); }
	 
}
