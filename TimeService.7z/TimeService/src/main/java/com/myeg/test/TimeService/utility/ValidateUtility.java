package com.myeg.test.TimeService.utility;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 
 * @author Ankit Khanijau
 * @date 28th Mar 2023
 * @version Time Service v1.0
 * @apiNote Code written as per wowcher code test.
 *
 */
public class ValidateUtility {

	public static boolean validateText(String inp) {
		if(valLength(inp)) {
			if(valSep(inp)) {
				if(isInt(inp.substring(0, 2)) && isInt(inp.substring(3), true)) {
					return true;
				}
			}
		}

		return false;
	}

	private static boolean valLength(String inp) {
		if(null != inp) {
			return inp.length() == 5 ? true : false;
		}

		return false;
	}

	private static boolean valSep(String inp) {
		if(null != inp) {
			return String.valueOf(inp.charAt(2)).equals(":") ? true : false;
		}

		return false;
	}

	private static boolean isInt(String inp) {
		return isInt(inp, false);
	}
	
	private static boolean isInt(String inp, boolean isSecondHalf) {
		int val = -1;

		try {
			if (null != inp) {
				val = Integer.parseInt(inp);
				
				boolean cond = false;
				if(isSecondHalf) {
					cond = val <=59 && val >=0;
				} else {
					cond = val <=23 && val >=0;
				}
				
				return cond;
			}
		} catch (NumberFormatException e) {
			System.err.print("Invalid Input");
			val = -1;
			return false;
		}

		return true;
	}

	public static String getTime() {
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
		return sdf.format(new Date());
	}

	/*
	 * public static void main(String[] args) { getTime(); }
	 */
}
