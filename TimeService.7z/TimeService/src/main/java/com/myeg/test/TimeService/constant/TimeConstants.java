package com.myeg.test.TimeService.constant;

/**
 * 
 * @author Ankit Khanijau
 * @date 28th Mar 2023
 * @version Time Service v1.0
 * @apiNote Code written as per wowcher code test.
 *
 */
public interface TimeConstants {
	String SD_1 = "one";
	String SD_2 = "two";
	String SD_3 = "three";
	String SD_4 = "four";
	String SD_5 = "five";
	String SD_6 = "six";
	String SD_7 = "seven";
	String SD_8 = "eight";
	String SD_9 = "nine";
	
	String DD_10 = "ten";
	String DD_11 = "eleven";
	String DD_12 = "twelve";
	String DD_13 = "thirteen";
	String DD_14 = "fourteen";
	String DD_15 = "fifteen";
	String DD_16 = "sixteen";
	String DD_17 = "seventeen";
	String DD_18 = "eighteen";
	String DD_19 = "nineteen";
	
	String TY_20 = "twenty";
	String TY_30 = "thirty";
	String TY_40 = "fourty";
	String TY_50 = "fifty";
}
